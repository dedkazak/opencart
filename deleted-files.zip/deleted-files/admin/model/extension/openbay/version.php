<?php
class ModelExtensionOpenBayVersion extends Model {
	public function version() {
		return (int)3250;
		
	}
}
